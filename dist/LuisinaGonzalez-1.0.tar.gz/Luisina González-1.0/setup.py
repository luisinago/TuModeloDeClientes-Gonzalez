from setuptools import setup

setup(
    name= "Luisina González",
    version= "1.0",
    author= "Luisina González",
    description= "Para esta pre-entrega decidí hacer un programa donde se pueda llamar a la entrega anterior y a esta nueva. \n En la nueva entrega decidí hacerla con la temática de Taylor Swift, sus álbums y sus relaciones a lo largo de la creación de estos álbums. Incluí la clase Clientes que se pedía pero en lugar de clientes son más bien 'Personas' que han estado en su vida. Además incluí un 'easter egg' (que es algo dentro de la cultura del fandom) y en este en particular puse a Kanye West y los álbums en que Taylor se ha referido de algún modo u otro a él. \n Como métodos incluí los dos magic methods (el constructor y el str) y los de ver_info_persona y relaciones.",
    author_email= "luisinago@gmail.com",
    packages=["paquete"])